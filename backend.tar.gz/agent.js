const db = require('./database');

async function executeTool(call) {
  const name = call.name;
  const args = call.args;

  if (name === "search_products") {
    return new Promise((resolve) => {
      let query = "SELECT * FROM products WHERE 1=1";
      let params = [];

      if (args.category) {
        query += " AND category LIKE ?";
        params.push(`%${args.category}%`);
      }
      if (args.brand) {
        query += " AND brand LIKE ?";
        params.push(`%${args.brand}%`);
      }
      if (args.color) {
        query += " AND color LIKE ?";
        params.push(`%${args.color}%`);
      }
      if (args.max_price) {
        query += " AND price <= ?";
        params.push(args.max_price);
      }

      db.all(query, params, (err, rows) => {
        if (err) {
          resolve({ action: "error", message: "Failed to search products." });
        } else {
          resolve({
            action: "show_products",
            products: rows
          });
        }
      });
    });
  }

  if (name === "navigate_to_page") {
    return {
      action: "navigate",
      url: args.page_url,
      message: `Navigating you to ${args.page_url}...`
    };
  }

  if (name === "add_to_cart") {
    return {
      action: "cart_updated",
      message: `Added product ${args.product_id} to your cart!`
    };
  }

  if (name === "compare_products") {
    return new Promise((resolve) => {
      if (!args.product_ids || args.product_ids.length === 0) {
        resolve({ action: "error", message: "No products provided for comparison." });
        return;
      }
      const placeholders = args.product_ids.map(() => '?').join(',');
      const query = `SELECT * FROM products WHERE id IN (${placeholders})`;
      db.all(query, args.product_ids, (err, rows) => {
        if (err) {
          resolve({ action: "error", message: "Failed to fetch products for comparison." });
        } else {
          resolve({
            action: "show_comparison",
            products: rows
          });
        }
      });
    });
  }

  return { action: "unknown", message: "Tool not recognized." };
}

const geminiTools = [{
  functionDeclarations: [
    {
      name: "search_products",
      description: "Search the store inventory for products based on category, price, brand, or color.",
      parameters: {
        type: "OBJECT",
        properties: {
          category: { type: "STRING", description: "e.g., Laptops, Shoes, Phones" },
          max_price: { type: "NUMBER", description: "Maximum price in INR" },
          brand: { type: "STRING", description: "e.g., Nike, Dell, Apple" },
          color: { type: "STRING", description: "e.g., Red, Black, Silver" }
        }
      }
    },
    {
      name: "navigate_to_page",
      description: "Navigate the user to a specific page.",
      parameters: {
        type: "OBJECT",
        properties: {
          page_url: { type: "STRING", description: "e.g., /cart, /checkout, /products" }
        },
        required: ["page_url"]
      }
    },
    {
      name: "add_to_cart",
      description: "Add a specific product to the user's cart.",
      parameters: {
        type: "OBJECT",
        properties: {
          product_id: { type: "STRING", description: "The ID of the product to add" },
          quantity: { type: "NUMBER", description: "How many to add" }
        },
        required: ["product_id"]
      }
    },
    {
      name: "compare_products",
      description: "Compare two or more products side by side.",
      parameters: {
        type: "OBJECT",
        properties: {
          product_ids: { 
            type: "ARRAY", 
            items: { type: "STRING" },
            description: "List of product IDs to compare"
          }
        },
        required: ["product_ids"]
      }
    }
  ]
}];

module.exports = {
  executeTool,
  geminiTools
};
