const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'users.db');

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error opening database', err.message);
  } else {
    console.log('Connected to the SQLite database.');
    db.run(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      isPremium INTEGER DEFAULT 0,
      isAdmin INTEGER DEFAULT 0
    )`, (err) => {
      if (err) {
        console.error('Error creating users table', err.message);
      }
    });

    db.run(`CREATE TABLE IF NOT EXISTS chats (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER NOT NULL,
      url TEXT NOT NULL,
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (userId) REFERENCES users(id)
    )`, (err) => {
      if (err) {
        console.error('Error creating chats table', err.message);
      }
    });

    db.run(`CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      brand TEXT NOT NULL,
      color TEXT,
      price INTEGER NOT NULL,
      image TEXT NOT NULL,
      url TEXT NOT NULL
    )`, (err) => {
      if (err) {
        console.error('Error creating products table', err.message);
      } else {
        // Seed mock data if empty
        db.get('SELECT COUNT(*) as count FROM products', [], (err, row) => {
          if (row && row.count === 0) {
            const seedProducts = [
              { id: 'p1', name: 'Nike Air Max', category: 'Shoes', brand: 'Nike', color: 'Red', price: 4500, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=200', url: '/product/p1' },
              { id: 'p2', name: 'Nike Running', category: 'Shoes', brand: 'Nike', color: 'Black', price: 3000, image: 'https://images.unsplash.com/photo-1491553895911-0055eca6402d?auto=format&fit=crop&q=80&w=200', url: '/product/p2' },
              { id: 'p3', name: 'Adidas Ultraboost', category: 'Shoes', brand: 'Adidas', color: 'White', price: 6000, image: 'https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?auto=format&fit=crop&q=80&w=200', url: '/product/p3' },
              { id: 'p4', name: 'Puma RS-X', category: 'Shoes', brand: 'Puma', color: 'Red', price: 4000, image: 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&q=80&w=200', url: '/product/p4' },
              { id: 'l1', name: 'Dell Inspiron 15', category: 'Laptops', brand: 'Dell', color: 'Silver', price: 45000, image: 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?auto=format&fit=crop&q=80&w=200', url: '/product/l1' },
              { id: 'l2', name: 'Dell XPS 13', category: 'Laptops', brand: 'Dell', color: 'Silver', price: 95000, image: 'https://images.unsplash.com/photo-1593642702821-c823b13eb2a2?auto=format&fit=crop&q=80&w=200', url: '/product/l2' },
              { id: 'l3', name: 'MacBook Air M2', category: 'Laptops', brand: 'Apple', color: 'Space Gray', price: 110000, image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&q=80&w=200', url: '/product/l3' },
              { id: 'l4', name: 'HP Pavilion', category: 'Laptops', brand: 'HP', color: 'Blue', price: 48000, image: 'https://images.unsplash.com/photo-1583847268964-b28e5f8db257?auto=format&fit=crop&q=80&w=200', url: '/product/l4' },
              { id: 'ph1', name: 'iPhone 14', category: 'Phones', brand: 'Apple', color: 'Red', price: 70000, image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&q=80&w=200', url: '/product/ph1' },
              { id: 'ph2', name: 'Samsung Galaxy S23', category: 'Phones', brand: 'Samsung', color: 'Black', price: 75000, image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?auto=format&fit=crop&q=80&w=200', url: '/product/ph2' },
            ];

            const stmt = db.prepare(`INSERT INTO products (id, name, category, brand, color, price, image, url) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
            seedProducts.forEach(p => {
              stmt.run([p.id, p.name, p.category, p.brand, p.color, p.price, p.image, p.url]);
            });
            stmt.finalize();
            console.log('Mock products seeded.');
          }
        });
      }
    });
  }
});

module.exports = db;
