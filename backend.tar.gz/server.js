require('dotenv').config({ path: __dirname + '/.env' });
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const cheerio = require('cheerio');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Razorpay = require('razorpay');
const crypto = require('crypto');
const helmet = require('helmet');
const db = require('./database');
const { executeTool, geminiTools } = require('./agent');

const app = express();

// Security Headers
app.use(helmet());

// Strict CORS Configuration
app.use(cors({
  origin: 'http://localhost:5173', // Allow only the frontend origin
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

app.use(express.json());

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'super-secret-jwt-key';

// Initialize Gemini API
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || 'fake-key-for-now');

// Initialize Razorpay
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || 'fake_key_id',
  key_secret: process.env.RAZORPAY_KEY_SECRET || 'fake_key_secret',
});

// --- AUTH MIDDLEWARE ---
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) return res.status(401).json({ error: 'Access denied. No token provided.' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid token.' });
    req.user = user;
    next();
  });
};

const checkPremium = (req, res, next) => {
  db.get(`SELECT isPremium FROM users WHERE id = ?`, [req.user.id], (err, row) => {
    if (err || !row) return res.status(500).json({ error: 'Error checking premium status.' });
    if (row.isPremium === 0) return res.status(403).json({ error: 'Premium subscription required.', requiresPayment: true });
    next();
  });
};

// --- AUTH ENDPOINTS ---
app.post('/api/auth/signup', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    // Automatically make the very first user the admin and premium
    db.get('SELECT COUNT(*) as count FROM users', [], (err, row) => {
      const isFirstUser = row && row.count === 0;
      const isAdmin = isFirstUser ? 1 : 0;
      const isPremium = isFirstUser ? 1 : 0; // Give the admin free premium

      db.run(`INSERT INTO users (email, password, isAdmin, isPremium) VALUES (?, ?, ?, ?)`, [email, hashedPassword, isAdmin, isPremium], function(err) {
        if (err) {
          if (err.message.includes('UNIQUE')) return res.status(400).json({ error: 'Email already exists.' });
          return res.status(500).json({ error: 'Error registering user.' });
        }
        const token = jwt.sign({ id: this.lastID, email, isAdmin }, JWT_SECRET, { expiresIn: '24h' });
        res.json({ token, isPremium, isAdmin });
      });
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error during signup.' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  db.get(`SELECT * FROM users WHERE email = ?`, [email], async (err, user) => {
    if (err || !user) return res.status(400).json({ error: 'Invalid email or password.' });

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ error: 'Invalid email or password.' });

    const token = jwt.sign({ id: user.id, email: user.email, isAdmin: user.isAdmin }, JWT_SECRET, { expiresIn: '24h' });
    res.json({ token, isPremium: user.isPremium, isAdmin: user.isAdmin });
  });
});

app.get('/api/auth/me', authenticateToken, (req, res) => {
  db.get(`SELECT id, email, isPremium, isAdmin FROM users WHERE id = ?`, [req.user.id], (err, user) => {
    if (err || !user) return res.status(404).json({ error: 'User not found.' });
    res.json(user);
  });
});

// --- ADMIN MIDDLEWARE ---
const authenticateAdmin = (req, res, next) => {
  if (!req.user || req.user.isAdmin !== 1) {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  next();
};

// --- ADMIN ENDPOINTS ---
app.get('/api/admin/users', authenticateToken, authenticateAdmin, (req, res) => {
  db.all(`SELECT id, email, isPremium, isAdmin FROM users ORDER BY id DESC`, [], (err, users) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch users.' });
    res.json(users);
  });
});

app.get('/api/admin/chats/:userId', authenticateToken, authenticateAdmin, (req, res) => {
  db.all(`SELECT id, url, question, answer, timestamp FROM chats WHERE userId = ? ORDER BY timestamp DESC`, [req.params.userId], (err, chats) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch chats.' });
    res.json(chats);
  });
});

// --- RAZORPAY PAYMENT ENDPOINTS ---
app.post('/api/payment/create-order', authenticateToken, async (req, res) => {
  try {
    const options = {
      amount: 999 * 100, // amount in the smallest currency unit (e.g., 999 INR)
      currency: "INR",
      receipt: `receipt_order_${req.user.id}_${Date.now()}`
    };
    const order = await razorpay.orders.create(options);
    res.json(order);
  } catch (error) {
    console.error('Razorpay Error:', error);
    res.status(500).json({ error: 'Failed to create payment order.' });
  }
});

app.post('/api/payment/verify', authenticateToken, (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
  
  const hmac = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || 'fake_key_secret');
  hmac.update(razorpay_order_id + "|" + razorpay_payment_id);
  const generatedSignature = hmac.digest('hex');

  if (generatedSignature === razorpay_signature) {
    // Payment is successful, upgrade user
    db.run(`UPDATE users SET isPremium = 1 WHERE id = ?`, [req.user.id], (err) => {
      if (err) return res.status(500).json({ error: 'Payment verified but failed to upgrade account.' });
      res.json({ success: true, message: 'Payment verified successfully! Account upgraded.' });
    });
  } else {
    res.status(400).json({ error: 'Invalid payment signature.' });
  }
});

// --- CHATBOT ENDPOINTS ---
let scrapedContexts = {}; // Store scraped content per user

app.post('/api/scrape', authenticateToken, checkPremium, async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: 'URL is required' });

  try {
    const baseUrl = new URL(url);
    const domain = baseUrl.origin;
    
    let visited = new Set();
    let queue = [url];
    let fullText = "";
    let pagesScraped = 0;
    const MAX_PAGES = 10;

    while (queue.length > 0 && visited.size < MAX_PAGES) {
      const currentUrl = queue.shift();
      
      // Skip if already visited or has hash fragment
      const cleanUrl = currentUrl.split('#')[0];
      if (visited.has(cleanUrl)) continue;
      
      visited.add(cleanUrl);

      try {
        const response = await axios.get(cleanUrl, { 
          headers: { 'User-Agent': 'Mozilla/5.0' },
          timeout: 5000 // Don't hang on slow pages
        });
        
        const $ = cheerio.load(response.data);
        $('script, style, noscript, iframe, img, svg, video').remove();
        
        // Extract text and append
        const pageText = $('body').text().replace(/\s+/g, ' ').trim();
        fullText += `\n\n--- Content from ${cleanUrl} ---\n\n` + pageText;
        pagesScraped++;

        // Find more links
        $('a').each((i, link) => {
          const href = $(link).attr('href');
          if (href) {
            try {
              const absoluteUrl = new URL(href, cleanUrl).href;
              const linkDomain = new URL(absoluteUrl).origin;
              
              // Only queue internal links that we haven't visited
              if (linkDomain === domain && !visited.has(absoluteUrl.split('#')[0])) {
                queue.push(absoluteUrl);
              }
            } catch (e) {
              // Ignore invalid URLs
            }
          }
        });
      } catch (pageError) {
        console.error(`Failed to scrape ${cleanUrl}:`, pageError.message);
        // Continue to the next URL in the queue
      }
    }

    if (pagesScraped === 0) {
      return res.status(500).json({ error: 'Failed to scrape any content from the URL.' });
    }

    scrapedContexts[req.user.id] = { url, text: fullText.substring(0, 500000) }; // Store up to 500k chars
    res.json({ message: `Deep scraping successful. Scraped ${pagesScraped} pages.`, url, pagesScraped });
  } catch (error) {
    console.error('Scraping initialization error:', error);
    res.status(500).json({ error: 'Invalid URL or failed to start scraping.' });
  }
});

app.post('/api/chat', authenticateToken, checkPremium, async (req, res) => {
  const { question } = req.body;
  const userContext = scrapedContexts[req.user.id];
  
  if (!question) return res.status(400).json({ error: 'Question is required' });
  if (!userContext) return res.status(400).json({ error: 'Please scrape a website first' });
  if (!process.env.GEMINI_API_KEY) return res.status(500).json({ error: 'Gemini API key is missing' });

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
    
    const prompt = `You are an advanced, natural-sounding AI assistant. Your task is to answer the user's question accurately based *only* on the provided website content.
    
    CRITICAL INSTRUCTIONS:
    1. Read the provided text carefully. It was scraped from a website, so there may be formatting artifacts or typos. Use advanced NLP context clues to understand it.
    2. Answer the user's question in a highly natural, conversational, and professional tone.
    3. Format your answer beautifully using Markdown (e.g., use bold text, bullet points, and short paragraphs for readability).
    4. If the answer is not explicitly in the text, you can infer slightly if obvious, otherwise politely say "I cannot find specific details about that in the provided website content."
    
    Website URL: ${userContext.url}
    
    Website Content:
    ${userContext.text}
    
    User Question: ${question}
    `;

    const result = await model.generateContent(prompt);
    const answerText = result.response.text();
    
    // Save to chat history
    db.run(`INSERT INTO chats (userId, url, question, answer) VALUES (?, ?, ?, ?)`, 
      [req.user.id, userContext.url, question, answerText], 
      (err) => {
        if (err) console.error("Failed to save chat to DB", err.message);
      }
    );

    res.json({ answer: answerText });
  } catch (error) {
    console.error('Gemini API Error:', error);
    let errorMessage = 'Failed to generate answer from the AI model';
    if (error.status === 429) {
      errorMessage = 'You have exceeded the rate limit for your Gemini API key (Too Many Requests). Please wait a few seconds and try again.';
    } else if (error.status === 503) {
      errorMessage = 'The AI model is currently overloaded. Please try again in a few minutes.';
    }
    res.status(error.status || 500).json({ error: errorMessage });
  }
});

app.post('/api/agent-chat', authenticateToken, checkPremium, async (req, res) => {
  const { question, history = [] } = req.body;
  if (!question) return res.status(400).json({ error: 'Question is required' });

  try {
    const model = genAI.getGenerativeModel({ 
      model: "gemini-2.5-flash",
      tools: geminiTools
    });

    const chat = model.startChat({
      history: history.map(msg => ({
        role: msg.role, // 'user' or 'model'
        parts: [{ text: msg.text }]
      }))
    });

    const result = await chat.sendMessage(question);
    const response = result.response;
    
    // Check if Gemini decided to call a tool
    if (response.functionCalls && response.functionCalls().length > 0) {
      const call = response.functionCalls()[0];
      const toolResult = await executeTool(call);
      
      // We return the structured JSON so the frontend can render product cards/tables
      return res.json({ 
        type: 'action', 
        data: toolResult,
        raw_text: response.text() // Optional text context
      });
    }

    // Standard text response
    res.json({ type: 'text', answer: response.text() });
  } catch (error) {
    console.error('Agent Chat Error:', error);
    res.status(500).json({ error: 'Failed to process agent request.' });
  }
});

app.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
});
